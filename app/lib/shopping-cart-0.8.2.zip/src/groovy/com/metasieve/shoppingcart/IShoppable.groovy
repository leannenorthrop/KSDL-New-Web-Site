package com.metasieve.shoppingcart

interface IShoppable {

}
