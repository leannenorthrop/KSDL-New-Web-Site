package com.metasieve.shoppingcart

class ShoppingItem {

}
