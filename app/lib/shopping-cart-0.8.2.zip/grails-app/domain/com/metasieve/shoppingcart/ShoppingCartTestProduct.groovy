package com.metasieve.shoppingcart

class ShoppingCartTestProduct extends Shoppable {
	String name
	
	String toString() {
		return name
	}
}
