class TwitterGrailsPlugin {

	def version = 0.2
	def dependsOn = [:]
	def author = 'Burt Beckwith'
	def authorEmail = 'burt@burtbeckwith.com'
	def title = 'Grails Twitter Plugin.'
	def description = 'Uses the JTwitter API (http://www.winterwell.com/software/jtwitter.php) to ' +
		'provide access to Twitter in a Grails application.'
	def documentation = 'http://grails.org/Twitter+Plugin'

	def doWithSpring = {}

	def doWithApplicationContext = { applicationContext -> }

	def doWithWebDescriptor = { xml -> }

	def doWithDynamicMethods = { ctx -> }

	def onChange = { event -> }

	def onConfigChange = { event -> }
}
