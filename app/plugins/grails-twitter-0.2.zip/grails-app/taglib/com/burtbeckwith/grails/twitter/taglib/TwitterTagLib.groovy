package com.burtbeckwith.grails.twitter.taglib

import java.util.regex.Pattern

import winterwell.jtwitter.Twitter.Message
import winterwell.jtwitter.Twitter.Status
import winterwell.jtwitter.Twitter.User

/**
 * Available <code>Message</code> properties:<br/> 
 * Date createdAt<br/>
 * int id<br/>
 * User recipient<br/>
 * User sender<br/>
 * String text<br/>
 * boolean isPublic()<br/>
 * boolean favorited<br/>
 * long inReplyToStatusId<br/>
 * String inReplyToScreenName<br/>
 * long inReplyToUserId<br/>
 * boolean truncated<br/>
 *<br/>
 *
 * Available <code>Status</code> properties:<br/> 
 * Date createdAt<br/>
 * long id<br/>
 * String text<br/>
 * User user<br/>
 * boolean favorited<br/>
 * long inReplyToStatusId<br/>
 * String inReplyToScreenName<br/>
 * long inReplyToUserId<br/>
 * boolean truncated<br/>
 *
 * Available <code>User</code> properties:<br/> 
 * String description<br/>
 * int id<br/>
 * String location<br/>
 * String name - the display name, e.g. "Daniel Winterstein"<br/>
 * URI profileImageUrl<br/>
 * boolean protectedUser<br/>
 * String screenName - the login name, e.g. "winterstein"<br/>
 * Status status<br/>
 * URI website<br/>
 *
 * @author <a href='mailto:burt@burtbeckwith.com'>Burt Beckwith</a>
 */
class TwitterTagLib {

	static namespace = 'twitter'

	def twitterService

	/**
	 * Gets direct messages and loops through them. <br/>
	 *
	 * Attributes include 'since' (Date) and 'sinceId' (long), both optional.
	 * These are used to limit the message count.<br/>
	 *
	 * Exposes each <code>Message</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def directMessages = { attrs, body ->
		Date sinceDate = attrs.since
		Long sinceId = attrs.sinceId

		try {
			def messages
			if (sinceDate) {
				messages = twitterService.getDirectMessages(sinceDate)
			}
			else if (sinceId) {
				messages = twitterService.getDirectMessages(sinceId)
			}
			else {
				messages = twitterService.directMessages
			}
			messages.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets recent direct messages and loops through them. <br/>
	 *
	 * Exposes each <code>Message</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def recentDirectMessages = { attrs, body ->
		try {
			twitterService.recentDirectMessages.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets reply messages and loops through them. <br/>
	 *
	 * Exposes each <code>Message</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def replies = { attrs, body ->
		try {
			twitterService.replies.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets followers and loops through them. <br/>
	 *
	 * Exposes each <code>User</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def followers = { attrs, body ->
		try {
			twitterService.followers.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets friends (people you follow) and loops through them. <br/>
	 *
	 * If the 'username' attribute (login name or numeric id) is present
	 * it finds that user's friends, otherwise it finds the logged-in user's.
	 *
	 * Exposes each <code>User</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def friends = { attrs, body ->
		String username = attrs.username

		try {
			def users
			if (username) {
				users = twitterService.getFriends(username)
			}
			else {
				users = twitterService.friends
			}

			users.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets Twitter 'featured users' and loops through them. <br/>
	 *
	 * Exposes each <code>User</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def featured = { attrs, body ->
		try {
			twitterService.featured.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets the user specified by the 'userId' attribute (username or numeric ID).<br/>
	 *
	 * Exposes the <code>User</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def user = { attrs, body ->
		String id = attrs.userId
		if (!id) {
			throwTagError("Tag [user] is missing required attribute 'userId'")
		}

		try {
			out << body(twitterService.show(id))
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets the current status for a user.<br/>
	 *
	 * If the 'username' attribute (login name) is present it finds that user's friends,
	 * otherwise if the 'userId' attribute (numeric id) is present it finds that user's friends,
	 * otherwise it finds the logged-in user's.
	 *
	 * Exposes the <code>User</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def status = { attrs, body ->
		Integer userId = attrs.userId
		String username = attrs.username

		try {
			def status
			if (userId) {
				status = twitterService.getStatus(userId)
			}
			else if (username) {
				status = twitterService.getStatus(username)
			}
			else {
				status = twitterService.status
			}

			out << body(status)
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets the 20 most recent statuses posted in the last 24 hours from the
	 * authenticated user and that user's friends.
	 *
	 * If the 'userId' attribute (login name or numeric id) is present it finds that user's
	 * statuses, otherwise it finds the logged-in user's.<br/>
	 *
	 * If the 'since' attribute (Date) is present it limits results to only those after that date.<br/>
	 *
	 * Exposes each <code>Status</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def friendsTimeline = { attrs, body ->
		String id = attrs.userId
		Date since = attrs.since

		try {
			def statuses
			if (id || since) {
				statuses = twitterService.getFriendsTimeline(id, since)
			}
			else {
				statuses = twitterService.friendsTimeline
			}

			statuses.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets the 20 most recent statuses from non-protected users who have set
	 * a custom user icon.
	 *
	 * Exposes each <code>Status</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def publicTimeline = { attrs, body ->
		try {
			twitterService.publicTimeline.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Gets the 20 most recent statuses posted in the last 24 hours from the
	 * authenticated user.
	 *
	 * If the 'userId' attribute (login name or numeric id) is present it finds that user's
	 * statuses, otherwise it finds the logged-in user's.<br/>
	 *
	 * If the 'since' attribute (Date) is present it limits results to only those after that date.<br/>
	 *
	 * If the 'count' attribute (int) is present it limits results to no more than that number.<br/>
	 *
	 * Exposes each <code>Status</code> as 'it' and evaluates the body to
	 * allow the caller to render the data.
	 */
	def userTimeline = { attrs,  body ->
		String id = attrs.userId
		Date since = attrs.since
		Integer count = attrs.count

		try {
			def statuses
			if (id || since || count) {
				statuses = twitterService.getUserTimeline(id, count, since)
			}
			else {
				statuses = twitterService.userTimeline
			}

			statuses.each { out << body(it) }
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Renders an &lt;img&gt; tag for a user's profile image.
	 *
	 * Attributes include 'user' (User), 'alt' (String, optional) for the tag's 'alt' attribute,
	 * and 'border' (int, optional) for the tag's 'border' attribute (defaults to 0).<br/>
	 *
	 * All other attributes are passed through to the tag.
	 */
	def profileImage = { attrs ->
		User user = attrs.remove('user')
		if (!user) {
			throwTagError("Tag [profileImage] is missing required attribute 'user'")
		}
		String alt = attrs.remove('alt') ?: ''
		int border = (attrs.remove('border') ?: 0).toInteger()
		out << """<img src="$user.profileImageUrl" alt="$alt" border='${border}'${generateExtraAttributes(attrs)} />"""
	}

	/**
	 * Convert urls to clickable links and @username to clickable Twitter homepage links.<br/>
	 *
	 * Attributes include 'text' (String), the text to mark up, 'links' (boolean) to specify
	 * whether to mark up links (defaults to true), and 'usernames' (boolean) to specify
	 * whether to mark up @username (defaults to true).
	 */
	def markup = { attrs, body ->
		String text = attrs.text
		if (!text) {
			throwTagError("Tag [markup] is missing required attribute 'text'")
		}

		boolean links = true
		boolean usernames = true
		if (attrs.links instanceof Boolean && !attrs.links) {
			links = false
		}
		if (attrs.usernames instanceof Boolean && !attrs.usernames) {
			usernames = false
		}

		if (links) {
			text = markupLinks(text)
		}

		if (usernames) {
			text = markupUsernameLinks(text)
		}

		out << text
	}

	/**
	 * Renders a link to a user's twitter.com page.<br/>
	 *
	 * Attributes include 'name' (String) the user's login name and 'text' (String, optional),
	 * the link text (defaults to the user's login name).
	 *
	 * All other attributes are passed through to the tag.
	 */
	def userLink = { attrs ->
		String screenName = attrs.remove('name')
		if (!screenName) {
			throwTagError("Tag [userLink] is missing required attribute 'name'")
		}

		String text = attrs.remove('text') ?: screenName

		attrs.url = 'http://twitter.com/' + screenName
		attrs.text = text
		out << url(attrs)
	}

	/**
	 * Renders a link to a tweet (status) twitter.com page.<br/>
	 *
	 * Attributes include 'name' (String) the user's login name and 'id' (long) the status id.
	 *
	 * All other attributes are passed through to the tag.
	 */
	def tweetLink = { attrs ->
		String screenName = attrs.remove('name')
		if (!screenName) {
			throwTagError("Tag [tweetLink] is missing required attribute 'name'")
		}
		if (!attrs.id) {
			throwTagError("Tag [tweetLink] is missing required attribute 'id'")
		}

		long id = attrs.remove('id').toLong()
		attrs.url = 'http://twitter.com/' + screenName + '/status/' + id
		attrs.text = id.toString()
		out << url(attrs)
	}

	/**
	 * Renders a link for a URL with a target of '_blank' (new window). If the 'url' attribute (URL)
	 * is <code>null</code>, nothing is rendered.
	 *
	 * The other attribute is 'text' (String), the link text to display (defaults to the URL).
	 *
	 * All other attributes are passed through to the tag.
	 */
	def url = { attrs ->
		def urlString = attrs.remove('url')?.toString()
		if (urlString) {
			String text = attrs.remove('text') ?: urlString
			out << "<a href=\"$urlString\" target='_blank'${generateExtraAttributes(attrs)}>$text</a>"
		}
	}

	/**
	 * Gets the remaining number of API requests available to the authenticating user before the
	 * API limit is reached for the current hour.
	 */
	def rateLimitStatus = { attrs ->
		try {
			out << twitterService.rateLimitStatus
		}
		catch (e) {
			handleException e
			return
		}
	}

	/**
	 * Convert urls to clickable links.
	 * @param text  the message or status text
	 * @return  the text with links rendered
	 */
	protected String markupLinks(String text) {
		def matcher = Pattern.compile(/(ftp|http|https|file):\/\/[\S]+(\b|$)/, Pattern.CASE_INSENSITIVE).matcher(text)
		return matcher.replaceAll('''<a href="$0" target='_blank'>$0</a>''')
	}

	/**
	 * Convert @username to clickable Twitter homepage links.
	 * @param text  the message or status text
	 * @return  the text with @username links rendered
	 */
	protected String markupUsernameLinks(String text) {
		def matcher = (text =~ /(@)([a-zA-Z0-9_]+)/)
		return matcher.replaceAll('''<a href='http://twitter.com/$2' target='_blank'>@$2</a>''')
	}

	protected void handleException(e) {
		request.setAttribute('twitterException', e)
		log.error e.message, e
	}

	/**
	 * Generates html for attributes not explicitly handled.
	 * <p/>
	 * Remove all handled attributes before calling this, e.g.
	 * <code>attrs.remove 'border'</code>
	 *
	 * @param attrs  the attribute map
	 * @return  html for extra attributes
	 */
	protected String generateExtraAttributes(attrs) {
		attrs.inject('') { extra, entry -> "$extra $entry.key=\"$entry.value\"" }
	}
}
