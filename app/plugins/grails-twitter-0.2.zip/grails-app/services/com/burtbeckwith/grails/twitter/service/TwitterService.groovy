package com.burtbeckwith.grails.twitter.service

import javax.servlet.http.Cookie

import org.apache.commons.codec.binary.Base64

import winterwell.jtwitter.Twitter
import winterwell.jtwitter.TwitterException
import winterwell.jtwitter.Twitter.Message
import winterwell.jtwitter.Twitter.Status
import winterwell.jtwitter.Twitter.User

import com.burtbeckwith.grails.twitter.CredentialsHolder

/**
 * Wraps and re-exposes the <a href='http://www.winterwell.com/software/jtwitter.php'>JTwitter</a> API,
 * and also provides authentication methods.
 *
 * @author <a href='mailto:burt@burtbeckwith.com'>Burt Beckwith</a>
 */class TwitterService {

	private static final String COOKIE_NAME = 'grails_twitter'

	boolean transactional = false

	// API wrapper methods

	// TODO  for long messages use public List<String> splitMessage(String longStatus)

	/**
	 * Befriends the specified user.
	 *
	 * @param username  the ID or screen name of the user to befriend
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the user
	 */
	User befriend(String username, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).befriend(username)
	}

	/**
	 * Discontinues friendship with the specified user.
	 *
	 * @param username  the ID or screen name of the user with whom to discontinue friendship.
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the user
	 */
	User breakFriendship(String username, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).breakFriendship(username)
	}

	/**
	 * Destroys the status specified by the required ID parameter.
	 * The authenticated user must be the author of the specified status.
	 *
	 * @param statusId  the id of the status to delete
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 */
	void destroyStatus(int statusId, Map authParams = [:]) throws TwitterException {
		createTwitter(authParams).destroyStatus(statusId)
	}

	/**
	 * Destroys the given status. The authenticated user must be the author of the status post.
	 *
	 * @param status  the status to delete
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 */
	void destroyStatus(Status status, Map authParams = [:]) throws TwitterException {
		createTwitter(authParams).destroyStatus(status)
	}

	/**
	 * Returns direct messages sent to the authenticated user.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the messages
	 */
	List<Message> getDirectMessages(Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getDirectMessages()
	}

	/**
	 * Get the remaining number of API requests available to the authenticated user before the API
	 * limit is reached for the current hour.
	 * <i>If this is negative you should stop using Twitter with this login for a bit.</i>  
	 * Note: Calls to rate_limit_status do not count against the rate limit.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the remaining number
	 */
	int getRateLimitStatus(Map authParams = [:]) {
		return createTwitter(authParams).getRateLimitStatus()
	}

	/**
	 * Returns the last 20 direct messages sent to the authenticated user.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the messages
	 */
	List<Message> getRecentDirectMessages(Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getRecentDirectMessages()
	}

	/**
	 * Returns the direct messages sent to the authenticated user.
	 *
	 * @param since  narrows the resulting list of direct messages to just those
	 *            sent after the specified date.
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the messages
	 */
	List<Message> getDirectMessages(Date since, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getDirectMessages(since)
	}

	/**
	 * Returns the direct messages sent to the authenticated user.
	 *
	 * @param sinceId   the id of a direct message.
	 *            Narrows the resulting list of direct messages to just those
	 *            sent after the specified message id.
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the messages
	 */
	List<Message> getDirectMessages(long sinceId, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getDirectMessages(sinceId)
	}

	/**
	 * Returns the users currently featured on the site.
	 *
	 * @return  the users
	 */
	List<User> getFeatured() throws TwitterException {
		return createTwitter().getFeatured()
	}

	/**
	 * Returns the authenticated user's followers.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the users
	 */
	List<User> getFollowers(Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getFollowers()
	}

	/**
	 * Returns the (latest 100) authenticated user's friends.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the users
	 */
	List<User> getFriends(Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getFriends()
	}

	/**
	 * Returns the (latest 100) given user's friends.
	 *
	 * @param username  the ID or screen name of the user
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the users
	 */
	List<User> getFriends(String username) throws TwitterException {
		return createTwitter().getFriends(username)
	}

	/**
	 * Returns the 20 most recent statuses posted in the last 24 hours from the
	 * authenticated user and that user's friends.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the statuses
	 */
	List<Status> getFriendsTimeline(Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getFriendsTimeline()
	}

	/**
	 * Returns the 20 most recent statuses posted in the last 24 hours from the
	 * user and that user's friends.
	 *
	 * @param id  optional, specifies the ID or screen name of the user for whom
	 *            to return the friends_timeline.
	 * @param since  optional, narrows the returned results to just those statuses
	 *            created after the specified date.
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the statuses
	 */
	List<Status> getFriendsTimeline(String id, Date since, Map authParams = [:]) throws TwitterException {
// TODO  seems to need auth
		return createTwitter(authParams).getFriendsTimeline(id, since)
	}

	/**
	 * Returns the 20 most recent statuses from non-protected users who have set
	 * a custom user icon.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the statuses
	 */
	List<Status> getPublicTimeline() throws TwitterException {
		return createTwitter().getPublicTimeline()
	}

	/**
	 * Returns the 20 most recent replies (status updates prefixed with
	 * @username) to the authenticated user.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the messages
	 */
	List<Message> getReplies(Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getReplies()
	}

	/**
	 * Get the current status of the authenticated user.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the status
	 */
	Status getStatus(Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getStatus()
	}

	/**
	 * Returns a single status.
	 *
	 * @param id  the numerical ID of the status
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the status
	 */
	Status getStatus(int id, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getStatus(id)
	}

	/**
	 * Get the current status of the given user.
	 *
	 * @param username  the username
	 * @return  the status
	 */
	Status getStatus(String username) throws TwitterException {
		return createTwitter().getStatus(username)
	}

	/**
	 * Returns the 20 most recent statuses posted in the last 24 hours from the
	 * authenticated user.
	 *
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the statuses
	 */
	List<Status> getUserTimeline(Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getUserTimeline()
	}

	/**
	 * Returns the most recent statuses posted in the last 24 hours from the specified user.
	 * <p>
	 * Authentication is needed to see the posts of a private user. 
	 *
	 * @param id  optional, specifies the ID or screen name of the user
	 * @param count  optional (defaults to 20), specifies the number of statuses to
	 *            retrieve. May not be greater than 20 for performance purposes.
	 * @param since  optional, narrows the returned results to just those
	 *            statuses created after the specified date.
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the statuses
	 */
	List<Status> getUserTimeline(String id, Integer count, Date since, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).getUserTimeline(id, count, since)
	}

	/**
	 * Sends a new direct message to the specified user from the authenticated user.
	 *
	 * @param recipient  the ID or screen name of the recipient user.
	 * @param text  the text of your direct message. Keep it under 140 characters!
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return the sent message
	 */
	Message sendMessage(String recipient, String text, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).sendMessage(recipient, text)
	}

	/**
	 * Sets the authenticated user's status.
	 *
	 * @param text  the text of your status update. Must not be more than 160
	 *            characters and should not be more than 140 characters to
	 *            ensure optimal display.
	 * @return  the posted status
	 */
	Status setStatus(String text, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).setStatus(text)
	}

	/**
	 * Get the user, specified by ID or screen name.
	 *
	 * @param id  the ID or screen name of a user
	 * @param authParams  optional map with 'username' and 'password' values for authentication,
	 *        uses cached credentials if not provided
	 * @return  the user
	 */
	User show(String id, Map authParams = [:]) throws TwitterException {
		return createTwitter(authParams).show(id)
	}

	// security methods

	/**
	 * Check if there are cached creditials from a session cookie.
	 * @return  <code>true</code> if there are cached creditials
	 */
	boolean isLoggedIn() {
		return CredentialsHolder.get() != null
	}

	/**
	 * Called by TwitterFilter to extract username/password from the session cookie.
	 * @param cookies  array of cookies, possibly <code>null</code>
	 */
	void findCredentials(cookies) {
		def cookie = cookies.find { COOKIE_NAME.equals(it.name) }
		if (!cookie) {
			return
		}

		String value = cookie.value
		byte[] bytes = value.bytes
		if (!Base64.isArrayByteBase64(bytes)) {
			return
		}

		String[] parts = new String(Base64.decodeBase64(bytes)).split('\n');
		CredentialsHolder.set parts[0], parts[1]
	}

	/**
	 * Called by login controller action.
	 * @param username  Twitter login name
	 * @param password  Twitter password
	 * @param request  http request
	 * @param response  http response
	 * @return  <code>true</code> if successful
	 */
	boolean login(String username, String password, request, response) {
		try {
			// there's no explicit login, so do a simple action that requires auth
			new Twitter(username, password).getStatus()

			createCookie username, password, request.contextPath ?: '/', response
			return true
		}
		catch (TwitterException e) {
			// the API needs a fine-grained exception hierarchy ... assume bad login
			return false
		}
	}

	/**
	 * Delete cookie and reset cached credentials.
	 * @param request  http request
	 * @param response  http response
	 */
	void logout(request, response) {
		createCookie null, 0, request.contextPath ?: '/', response
		CredentialsHolder.reset()
	}

	private void createCookie(String username, String password, String path, response) {

		String value = new String(Base64.encodeBase64(
				(username.trim() + '\n' + password.trim()).bytes))

		createCookie value, -1, path, response
	}

	private void createCookie(String value, int maxAge, String path, response) {
		def cookie = new Cookie(COOKIE_NAME, value)
		cookie.maxAge = maxAge
		cookie.path = path
		response.addCookie cookie
	}

	/**
	 * Create a <code>Twitter</code> instance with a username and password. If
	 * <code>username</code> and <code>password</code> are passed, those are used.
	 * Otherwise the cached credentials are used, if available. If not, then no
	 * username/password are used, which works for the methods that don't require
	 * authentication (getFeatured(),  getFriends(String), getPublicTimeline(), getStatus(String))
	 * but will fail otherwise.
	 *
	 * @param authParams  optional username and password
	 * @return  the helper instance
	 */
	private Twitter createTwitter(Map authParams = [:]) {
		String username = authParams.username ?: null
		String password = authParams.password ?: null
		if (!username || !password) {
			String[] usernameAndPassword = CredentialsHolder.get()
			if (usernameAndPassword) {
				username = usernameAndPassword[0]
				password = usernameAndPassword[1]
			}
		}
		return new Twitter(username, password)
	}
}
