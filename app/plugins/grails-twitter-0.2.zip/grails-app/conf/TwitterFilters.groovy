import com.burtbeckwith.grails.twitter.CredentialsHolder

/**
 * Extracts username/password from session cookie before requests and clears the ThreadLocal cache after.
 *
 * @author <a href='mailto:burt@burtbeckwith.com'>Burt Beckwith</a>
 */
class TwitterFilters {

	def filters = {
		twitterLogin(controller: '*', action: '*') {

			/**
			 * Extract username/password from the session cookie.
			 */
			before = {
				applicationContext.twitterService.findCredentials request.cookies
			}

			/**
			 * If logged in, add the username to the model.
			 */
			after = { Map model ->
				if (model && CredentialsHolder.get()) {
					model.username = CredentialsHolder.get()[0]
				}
			}

			/**
			 * Reset the credentials.
			 */
			afterView = {
				CredentialsHolder.reset()
			}
		}
	}
}
