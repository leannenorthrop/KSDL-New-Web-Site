package com.burtbeckwith.grails.twitter;

/**
 * Uses a {@link ThreadLocal} to keep username/password.
 *
 * @author <a href='mailto:burt@burtbeckwith.com'>Burt Beckwith</a>
 */
public final class CredentialsHolder {

	private static final ThreadLocal<String[]> HOLDER = new ThreadLocal<String[]>();

	private CredentialsHolder() {
		// static only
	}

	/**
	 * Clear cached data.
	 */
	public static void reset() {
		HOLDER.set(null);
	}

	/**
	 * Set the username and password.
	 * @param username  the username
	 * @param password  the password
	 */
	public static void set(final String username, final String password) {
		HOLDER.set(new String[] { username, password });
	}

	/**
	 * Get the current username/password.
	 * @return  2-element array, 1st is username, 2nd is password, or <code>null</code> if not logged in
	 */
	public static String[] get() {
		return HOLDER.get();
	}
}
