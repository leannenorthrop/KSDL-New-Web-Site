package com.metasieve.magicnumbers

class MagicNumbersMixin {
	static getFromNow = { delegate ->
		Date currentDate = new Date()
		currentDate.setTime(currentDate.time + delegate)
		return currentDate.time
	}
	
	static getAgo = { delegate ->
		Date currentDate = new Date()
		currentDate.setTime(currentDate.time - delegate)
		return currentDate.time
	}
	
	static toDate = { delegate ->
		Date date = new Date(delegate)
	}
	
	static ordinalize = { delegate ->
		String stringRepresentation = delegate.toString()
		String lastDigit = stringRepresentation[-1]
		
		String ordinalSuffix
		switch (lastDigit) {
			case '1':
				ordinalSuffix = 'st'
				break
			case '2':
				ordinalSuffix = 'nd'
				break
			case '3':
				ordinalSuffix = 'rd'
				break
			default:
				ordinalSuffix = 'th'
		}
		
		stringRepresentation + ordinalSuffix
	}

    static getBytes = { delegate ->
		return delegate
    }

    static getByte = { delegate ->
		delegate.bytes
    }

    static getKilobytes = { delegate ->
		new Long(delegate.longValue() * 1024l)
    }

    static getKilobyte = { delegate ->
		delegate.kilobytes
    }

    static getMegabytes = { delegate ->
		new Long(delegate.longValue() * 1024l * 1024l)
    }

    static getMegabyte = { delegate ->
		delegate.megabytes
    }

    static getGigabytes = { delegate ->
		new Long(delegate.longValue() * 1024l * 1024l * 1024l)
    }

    static getGigabyte = { delegate ->
		delegate.gigabytes
    }

    static getTerabytes = { delegate ->
		new Long(delegate.longValue() * 1024l * 1024l * 1024l * 1024l)
    }

    static getTerabyte = { delegate ->
		delegate.terabytes
    }

    static getPetabytes = { delegate ->
		new Long(delegate.longValue() * 1024l * 1024l * 1024l * 1024l * 1024l)
    }

    static getPetabyte = { delegate ->
		delegate.petabytes
    }

    static getExabytes = { delegate ->
		new Long(delegate.longValue() * 1024l * 1024l * 1024l * 1024l * 1024l * 1024l)
    }

    static getExabyte = { delegate ->
		delegate.exabytes
    }

    static getSeconds = { delegate ->
		new Long(delegate.longValue() * 1000l)
    }

    static getSecond = { delegate ->
		delegate.seconds
    }

   	static getMinutes = { delegate ->
		new Long(delegate.longValue() * 60l * 1000l)
    }

    static getMinute = { delegate ->
		delegate.minutes
    }

    static getHours = { delegate ->
		new Long(delegate.minutes.longValue() * 60l)
    }

    static getHour = { delegate ->
		delegate.hours
    }

    static getDays = { delegate ->
		new Long(delegate.hours.longValue() * 24l)
    }

    static getDay = { delegate ->
		delegate.days
    }

    static getWeeks = { delegate ->
		new Long(delegate.days.longValue() * 7l)
    }

    static getWeek = { delegate ->
		delegate.weeks
    }

    static getFortnights = { delegate ->
		new Long(delegate.weeks.longValue() * 2l)
    }

    static getFortnight = { delegate ->
		delegate.fortnights
    }

    static getMonths = { delegate ->
		new Long(delegate.weeks.longValue() * 4l)
    }

    static getMonth = { delegate ->
		delegate.months
    }

    static getYears = { delegate ->
		new Long(delegate.months.longValue() * 12l)
    }

    static getYear = { delegate ->
		delegate.years
    }
	
	static mixinDatesToInteger() {
		Integer.metaClass.getFromNow = { ->
			MagicNumbersMixin.getFromNow(delegate)
		}
		
		Integer.metaClass.getAgo = { ->
			MagicNumbersMixin.getAgo(delegate)
		}
		
		Integer.metaClass.toDate = { ->
			MagicNumbersMixin.toDate(delegate)
		}
	}
	
	static mixinDatesToLong() {
		Long.metaClass.getFromNow = { ->
			MagicNumbersMixin.getFromNow(delegate)
		}
		
		Long.metaClass.getAgo = { ->
			MagicNumbersMixin.getAgo(delegate)
		}
		
		Long.metaClass.toDate = { ->
			MagicNumbersMixin.toDate(delegate)
		}
	}
	
    static mixinNumbersToInteger() {
		Integer.metaClass.ordinalize = { ->
			MagicNumbersMixin.ordinalize(delegate)
		}

	    Integer.metaClass.getBytes = { ->
			MagicNumbersMixin.getBytes(delegate)
        }

	    Integer.metaClass.getByte = { ->
			MagicNumbersMixin.getByte(delegate)
        }

	    Integer.metaClass.getKilobytes = { ->
			MagicNumbersMixin.getKilobytes(delegate)
        }

	    Integer.metaClass.getKilobyte = { ->
			MagicNumbersMixin.getKilobyte(delegate)
        }

	    Integer.metaClass.getMegabytes = { ->
			MagicNumbersMixin.getMegabytes(delegate)
        }

	    Integer.metaClass.getMegabyte = { ->
			MagicNumbersMixin.getMegabyte(delegate)
        }

	    Integer.metaClass.getGigabytes = { ->
			MagicNumbersMixin.getGigabytes(delegate)
        }

	    Integer.metaClass.getGigabyte = { ->
			MagicNumbersMixin.getGigabyte(delegate)
        }

	    Integer.metaClass.getTerabytes = { ->
			MagicNumbersMixin.getTerabytes(delegate)
        }

	    Integer.metaClass.getTerabyte = { ->
			MagicNumbersMixin.getTerabyte(delegate)
        }

	    Integer.metaClass.getPetabytes = { ->
			MagicNumbersMixin.getPetabytes(delegate)
        }

	    Integer.metaClass.getPetabyte = { ->
			MagicNumbersMixin.getPetabyte(delegate)
        }

	    Integer.metaClass.getExabytes = { ->
			MagicNumbersMixin.getExabytes(delegate)
        }

	    Integer.metaClass.getExabyte = { ->
			MagicNumbersMixin.getExabyte(delegate)
        }

        Integer.metaClass.getSeconds = { ->
			MagicNumbersMixin.getSeconds(delegate)
        }

        Integer.metaClass.getSecond = { ->
			MagicNumbersMixin.getSecond(delegate)
        }

        Integer.metaClass.getMinutes = { ->
			MagicNumbersMixin.getMinutes(delegate)
        }

        Integer.metaClass.getMinute = { ->
			MagicNumbersMixin.getMinute(delegate)
        }

        Integer.metaClass.getHours = { ->
			MagicNumbersMixin.getHours(delegate)
        }

        Integer.metaClass.getHour = { ->
			MagicNumbersMixin.getHour(delegate)
        }

        Integer.metaClass.getDays = { ->
			MagicNumbersMixin.getDays(delegate)
        }

        Integer.metaClass.getDay = { ->
			MagicNumbersMixin.getDay(delegate)
        }

        Integer.metaClass.getWeeks = { ->
			MagicNumbersMixin.getWeeks(delegate)
        }

        Integer.metaClass.getWeek = { ->
			MagicNumbersMixin.getWeek(delegate)
        }

        Integer.metaClass.getFortnights = { ->
			MagicNumbersMixin.getFortnights(delegate)
        }

        Integer.metaClass.getFortnight = { ->
			MagicNumbersMixin.getFortnight(delegate)
        }

        Integer.metaClass.getMonths = { ->
			MagicNumbersMixin.getMonths(delegate)
        }

        Integer.metaClass.getMonth = { ->
			MagicNumbersMixin.getMonth(delegate)
        }

        Integer.metaClass.getYears = { ->
			MagicNumbersMixin.getYears(delegate)
        }

        Integer.metaClass.getYear = { ->
			MagicNumbersMixin.getYear(delegate)
        }
	}
	
	static mixinNumbersToLong() {
		Long.metaClass.ordinalize = { ->
			MagicNumbersMixin.ordinalize(delegate)
		}

	    Long.metaClass.getBytes = { ->
			MagicNumbersMixin.getBytes(delegate)
        }

	    Long.metaClass.getByte = { ->
			MagicNumbersMixin.getByte(delegate)
        }

	    Long.metaClass.getKilobytes = { ->
			MagicNumbersMixin.getKilobytes(delegate)
        }

	    Long.metaClass.getKilobyte = { ->
			MagicNumbersMixin.getKilobyte(delegate)
        }

	    Long.metaClass.getMegabytes = { ->
			MagicNumbersMixin.getMegabytes(delegate)
        }

	    Long.metaClass.getMegabyte = { ->
			MagicNumbersMixin.getMegabyte(delegate)
        }

	    Long.metaClass.getGigabytes = { ->
			MagicNumbersMixin.getGigabytes(delegate)
        }

	    Long.metaClass.getGigabyte = { ->
			MagicNumbersMixin.getGigabyte(delegate)
        }

	    Long.metaClass.getTerabytes = { ->
			MagicNumbersMixin.getTerabytes(delegate)
        }

	    Long.metaClass.getTerabyte = { ->
			MagicNumbersMixin.getTerabyte(delegate)
        }

	    Long.metaClass.getPetabytes = { ->
			MagicNumbersMixin.getPetabytes(delegate)
        }

	    Long.metaClass.getPetabyte = { ->
			MagicNumbersMixin.getPetabyte(delegate)
        }

	    Long.metaClass.getExabytes = { ->
			MagicNumbersMixin.getExabytes(delegate)
        }

	    Long.metaClass.getExabyte = { ->
			MagicNumbersMixin.getExabyte(delegate)
        }

        Long.metaClass.getSeconds = { ->
			MagicNumbersMixin.getSeconds(delegate)
        }

        Long.metaClass.getSecond = { ->
			MagicNumbersMixin.getSecond(delegate)
        }

        Long.metaClass.getMinutes = { ->
			MagicNumbersMixin.getMinutes(delegate)
        }

        Long.metaClass.getMinute = { ->
			MagicNumbersMixin.getMinute(delegate)
        }

        Long.metaClass.getHours = { ->
			MagicNumbersMixin.getHours(delegate)
        }

        Long.metaClass.getHour = { ->
			MagicNumbersMixin.getHour(delegate)
        }

        Long.metaClass.getDays = { ->
			MagicNumbersMixin.getDays(delegate)
        }

        Long.metaClass.getDay = { ->
			MagicNumbersMixin.getDay(delegate)
        }

        Long.metaClass.getWeeks = { ->
			MagicNumbersMixin.getWeeks(delegate)
        }

        Long.metaClass.getWeek = { ->
			MagicNumbersMixin.getWeek(delegate)
        }

        Long.metaClass.getFortnights = { ->
			MagicNumbersMixin.getFortnights(delegate)
        }

        Long.metaClass.getFortnight = { ->
			MagicNumbersMixin.getFortnight(delegate)
        }

        Long.metaClass.getMonths = { ->
			MagicNumbersMixin.getMonths(delegate)
        }

        Long.metaClass.getMonth = { ->
			MagicNumbersMixin.getMonth(delegate)
        }

        Long.metaClass.getYears = { ->
			MagicNumbersMixin.getYears(delegate)
        }

        Long.metaClass.getYear = { ->
			MagicNumbersMixin.getYear(delegate)
        }
	}
}
