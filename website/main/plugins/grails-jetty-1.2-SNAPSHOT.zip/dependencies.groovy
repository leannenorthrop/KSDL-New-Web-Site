grails.project.dependency.resolution = {
    inherits "global" // inherit Grails' default dependencies
    log "warn" // log level of Ivy resolver, either 'error', 'warn', 'info', 'debug' or 'verbose'
    repositories {        
        grailsPlugins()
        grailsHome()

        // uncomment the below to enable remote dependency resolution
        // from public Maven repositories
        mavenLocal()
        mavenCentral()
    }
    dependencies {
        // specify dependencies here under either 'build', 'compile', 'runtime', 'test' or 'provided' scopes eg.
        runtime 'org.mortbay.jetty:jetty:6.1.21',
				'org.mortbay.jetty:jetty-naming:6.1.21',
				'org.mortbay.jetty:jetty-util:6.1.21',
				'org.mortbay.jetty:jetty-plus:6.1.21'

		runtime('org.mortbay.jetty:jsp-2.0:6.1.21') {
			excludes 'commons-el','ant', 'sl4j-api','sl4j-simple','jcl104-over-slf4j','xercesImpl','xmlParserAPIs'
		}
				
    }

}
